// Angel Proposal PWA - app.js
// Data embedded from CSV for offline-first usage.
const TOOLS = [{"工具ID": "MIX-01-心靈淨化", "工具名稱": "Angel｜心靈淨化 PWA", "核心功能": "清空認知、重置神經、校準注意力。", "適用對象/痛點": "#腦袋停不下來 #情緒很滿 #睡前放下 #關係降噪 #心超載", "對應篇章": "心靈感悟第8章；教養幸福經；家庭9生活劇本", "操作步驟": "①清空卸載；②呼吸重置；③感恩校準", "智多星錦囊": "親愛的，腦袋太吵時，我們先不急著想通。給心一點空間，清空噪音，把穩定的自己找回來。", "工具連結": "https://angel0973180707.github.io/Angel-inner-clean/", "性質分類": "綜合/基礎定頻工具", "影片名稱": "", "影片連結": ""}, {"工具ID": "EQ-01-心靈調味師", "工具名稱": "心靈調味師 PWA", "核心功能": "分辨感受滋味，30秒斷電，讓情緒降溫，換一種說法。", "適用對象/痛點": "#緒快爆開 #想回話怕後悔 #親子卡住的瞬間 #杏仁核劫持 #辨別感受釋放壓力", "對應篇章": "校園11（心球星球）；校園13（順勢療法）；創作1（思維超能力）", "操作步驟": "①選味道；②30秒斷電；③換說法；④甜美存檔", "智多星錦囊": "親愛的，在開口前，請先給自己30秒。打開調味師，選個味道，讓心先站穩。", "工具連結": "https://angel0973180707.github.io/angel-inner-seasoning/", "性質分類": "個人情緒冷卻/緊急斷電", "影片名稱": "", "影片連結": ""}, {"工具ID": "EQ-02-五感覺察", "工具名稱": "Angel｜五感覺察 PWA", "核心功能": "透過分齡感官練習，清空紛亂思緒，讓心回到感官專注。", "適用對象/痛點": "#焦慮煩惱 #偏見起伏 #心亂如麻 #親子共練 #感官定錨", "對應篇章": "校園11（情緒星球）；心靈感悟第8章；教養幸福經", "操作步驟": "①選停留時間；②選語音狀態；③選練習對象（大人/青少/孩童/幼兒）", "智多星錦囊": "親愛的，當心亂、焦慮時，我們先不談道理，先讓身體回來。試試五感覺察，聽聽笑長的聲音，陪您在呼吸中把心站穩。", "工具連結": "https://angel0973180707.github.io/Angel-Breath/", "性質分類": "個人情緒冷卻/感官覺察", "影片名稱": "", "影片連結": ""}, {"工具ID": "COM-01-反應選擇", "工具名稱": "改變｜換一個反應 PWA", "核心功能": "在情緒衝動當下爭取空間，將「反應」轉化為「選擇」。", "適用對象/痛點": "#反應太快 #後悔回話 #慣性吼叫 #停不下來 #需要空間", "對應篇章": "校園12（心理台階）；校園13（順勢療法）；創作3（就是要你管）", "操作步驟": "①暫停（呼吸/填寫感受）；②看見（描述現狀/念頭）；③換反應（選一句說得出口的話）", "智多星錦囊": "親愛的，有些時候不是我們不知道怎麼做，而是反應太快了。我們先不急著變好，試著用這個工具，陪您慢一點點，把方向盤交回自己手上。", "工具連結": "https://angel0973180707.github.io/angel-change-pwa/", "性質分類": "溝通轉譯/反應選擇", "影片名稱": "", "影片連結": ""}, {"工具ID": "ACT-01-財商練功", "工具名稱": "零用錢練功房 PWA（含家庭修練契約）", "核心功能": "透過30秒冷靜期訓練前額葉，建立「儲蓄>消費」的多巴胺回路。", "適用對象/痛點": "#衝動購物 #沒錢就伸手 #分不清想要與需要 #缺乏耐性 #親子金錢衝突", "對應篇章": "腦科學原稿第9章；不打不罵怎麼教3.3校園篇；心靈感悟第8章", "操作步驟": "①設定預算與利息；②簽署家庭契約；③消費時啟動30秒冷靜期；④結算領利息與能量扭蛋", "智多星錦囊": "親愛的，孩子想要東西等不及嗎？這不是壞習慣，是前額葉還在練功。送您這份「零用錢練功房」，陪孩子玩一場理財遊戲，讓他在等待中長出受用一生的理智腦。", "工具連結": "https://angel0973180707.github.io/happy-pocket-v1.6.2/", "性質分類": "行為改變/理財商數（ACT）", "影片名稱": "", "影片連結": ""}, {"工具ID": "ACT-02-自主啟動", "工具名稱": "自主能力啟動訓練ppt（Canva 範例版）", "核心功能": "透過視覺化計畫與節律練習，減少催促，啟動孩子內在的行動力。", "適用對象/痛點": "#起床拖延 #寫功課要人催 #生活沒規律 #慢郎中孩子 #親子口角", "對應篇章": "校園15（化被動為主動）", "操作步驟": "見簡報示範", "智多星錦囊": "孩子不是不動，他只是還在校準自己的軌道。這份「自主能力啟動訓練」送給您，讓我們用視覺替代碎念，陪孩子長出自己的節律，成為那顆穩健運行的衛星。", "工具連結": "https://www.canva.com/design/DAG6sVjMh-Q/h59LD3VCcXVMPV9mTqOnbQ/edit?utm_content=DAG6sVjMh-Q&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton", "性質分類": "行為改變/自主養成（ACT）", "影片名稱": "", "影片連結": ""}, {"工具ID": "REL-02-校園危機處理", "工具名稱": "校園衝突角色定位指南（親師行政三方守則）", "核心功能": "釐清衝突發生時各方的心理邊界與行動職責，防止事件擴大，將危機轉化為教育契機。", "適用對象/痛點": "#校園衝突事件處理 #校園霸凌爭議 #親師溝通斷裂 #媒體爆料壓力 #行政介入失當 #事件真相模糊", "對應篇章": "", "操作步驟": "見工具引導", "智多星錦囊": "校園衝突事件發生時，家長、老師、行政、媒體應該扮演什麼角色，守住什麼界限，讓危機變轉機，讓教育功能充分發揮。", "工具連結": "https://bit.ly/44tr2a5", "性質分類": "教養關係建立/校園溝通（REL）", "影片名稱": "高雄校園衝突事件", "影片連結": "https://youtu.be/ifDONHtq6nQ?si=KcEfbrwdt57iVa-T"}, {"工具ID": "EQ-03-心懂OK蹦", "工具名稱": "心懂OK蹦｜解碼幸福關係", "核心功能": "結合腦神經科學，透過紅、藍、黃三色能量球進行情緒急救與關係解碼。", "適用對象/痛點": "#吵架火大 #心裡委屈 #溝通斷線 #想找回平靜 #關係解碼", "對應篇章": "", "操作步驟": "1點擊紅球滅火冷靜；2點擊藍球翻譯行為；3點擊黃球修復行動；4領取天使笑長的祝福", "智多星錦囊": "親愛的幸福夥伴，當衝突發生、大腦「發炎」時，我們先不談道理。讓天使笑長陪你用這顆「心懂OK蹦」，帶領大腦從情緒風暴回到理智連結，把愛的力量找回來。我們一起加油！", "工具連結": "https://angel0973180707.github.io/angel-lucky/", "性質分類": "", "影片名稱": "", "影片連結": ""}, {"工具ID": "KIDS-01-快樂芒果", "工具名稱": "快樂芒果 PWA", "核心功能": "建立親子連結、用小步驟引導孩子專注與學習興趣、親子共樂。", "適用對象/痛點": "#學齡前 #國小低年級 #專注力短暫 #坐不住 #缺乏學習動機 #飛得慢的衛星", "對應篇章": "家庭3｜被打的芒果", "操作步驟": "情緒優先→看說玩用四步塑形→和平契約", "智多星錦囊": "孩子學習卡住時，先把關係抱回來、把大腦拉回線；再把學習拆成一小步一小步，幫助孩子回到專注裡。你的耐心陪伴，是孩子最大的福氣。（看｜說｜玩｜用 四步塑形）", "工具連結": "https://angel0973180707.github.io/happy-mango/", "性質分類": "親子連結/行為塑形/學習引導", "影片名稱": "被打的芒果", "影片連結": "https://youtu.be/p1WXzRhoUjg?si=qqEmL_dIDSnvxp45"}, {"工具ID": "MIX-02-情緒急救", "工具名稱": "幽默｜情緒急救包 PWA", "核心功能": "情緒上來時（前），幽默彼此一下，緩和氣氛，讓理智有時間回線。", "適用對象/痛點": "#快要斷線了 #育兒高壓 #僵持不下 #想發火但不想傷人", "對應篇章": "腦神經科學第九章；不打不罵怎麼教3.3", "操作步驟": "①開彩蛋：領取心聲提醒；②找回嘴：選幽默句化解；③存正能：留話給未來的自己", "智多星錦囊": "親愛的，當火氣快衝上頭時，我們先停一秒換個頻道。幽默不是軟弱，是給愛留一條回家的路。", "工具連結": "https://angel0973180707.github.io/angel-happy-m1/", "性質分類": "綜合/情緒緩衝工具", "影片名稱": "我陶醉了", "影片連結": ""}];

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

const els = {
  toolMain: $('#toolMain'),
  toolSub: $('#toolSub'),
  audience: $('#audience'),
  goal: $('#goal'),
  duration: $('#duration'),
  host: $('#host'),
  topic: $('#topic'),
  pain: $('#pain'),
  notes: $('#notes'),
  output: $('#output'),
  savedList: $('#savedList'),
  btnGenerate: $('#btnGenerate'),
  btnCopy: $('#btnCopy'),
  btnDownload: $('#btnDownload'),
  btnSave: $('#btnSave'),
  btnReset: $('#btnReset'),
  btnExportCsv: $('#btnExportCsv'),
  btnInstall: $('#btnInstall'),
};

let proposalType = 'talk'; // talk | course | event

function escapeCsvValue(v) {
  const s = (v ?? '').toString();
  if (/[",\n\r]/.test(s)) return '"' + s.replaceAll('"','""') + '"';
  return s;
}

function toolsToCsv() {
  const headers = Object.keys(TOOLS[0] || {});
  const lines = [headers.join(',')];
  for (const r of TOOLS) {
    lines.push(headers.map(h => escapeCsvValue(r[h])).join(','));
  }
  return lines.join('\n');
}

function downloadText(filename, text) {
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function setSegActive(type) {
  proposalType = type;
  $$('.seg-btn').forEach(btn => {
    const active = btn.dataset.type === type;
    btn.classList.toggle('active', active);
    btn.setAttribute('aria-selected', active ? 'true' : 'false');
  });
}

function fillToolSelects() {
  const opts = TOOLS.map(t => `<option value="${t['工具ID']}">${t['工具ID']}｜${t['工具名稱']}</option>`).join('');
  els.toolMain.innerHTML = `<option value="">（請選）</option>` + opts;
  els.toolSub.innerHTML  = `<option value="">（不選也可以）</option>` + opts;
}

function findTool(id) {
  return TOOLS.find(t => t['工具ID'] === id) || null;
}

function proposalTemplate({type, topic, audience, goal, duration, host, pain, notes, mainTool, subTool}) {
  const typeName = type === 'talk' ? '演講' : (type === 'course' ? '課程' : '活動');
  const now = new Date();
  const dateStr = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;

  const main = mainTool ? `【主工具】${mainTool['工具名稱']}（${mainTool['工具ID']}）\n- 核心功能：${mainTool['核心功能']}\n- 操作步驟：${mainTool['操作步驟']}\n- 智多星錦囊：${mainTool['智多星錦囊']}\n- 工具連結：${mainTool['工具連結']}\n` : '【主工具】（未選）\n';
  const sub  = subTool ? `\n【副工具】${subTool['工具名稱']}（${subTool['工具ID']}）\n- 功能：${subTool['核心功能']}\n- 連結：${subTool['工具連結']}\n` : '';

  const outline = (() => {
    if (type === 'talk') {
      return [
        '【流程建議（60–120分鐘可調）】',
        '1) 破冰：一句話看見現場壓力（2–5分鐘）',
        '2) 科學解碼：為什麼會失控（杏仁核劫持→前額葉回線）（10–15分鐘）',
        '3) 現場練習：主工具帶領（15–25分鐘）',
        '4) 情境演練：把「反應」換成「選擇」（15–25分鐘）',
        '5) 帶回家：一張小抄＋一個家庭練功任務（5–10分鐘）',
      ].join('\n');
    }
    if (type === 'course') {
      return [
        '【課程架構建議（可做 3–6 週）】',
        '第1週：把心站穩（情緒斷點與身體回線）',
        '第2週：翻譯行為（看見需求、拆解衝突）',
        '第3週：換說法（溝通轉譯與界線）',
        '第4週：家庭/班級練功（儀式化與復盤）',
        '（選配）第5–6週：個案診間＋工具串接',
      ].join('\n');
    }
    return [
      '【活動設計建議（半日/一日可調）】',
      'A. 入口：情緒急救站（3分鐘工具快測）',
      'B. 互動：情境關卡（親子/親師角色扮演）',
      'C. 工具區：主工具深度體驗（分站輪轉）',
      'D. 成果：把一句「說得出口」帶回家（小卡＋QR）',
    ].join('\n');
  })();

  const deliverables = [
    '【交付物】',
    '- 現場投影片（或講義PDF）',
    '- 工具QR（主工具＋副工具）',
    '- 練功任務小卡（7天可完成）',
    '-（可選）會後回饋表與追蹤指引'
  ].join('\n');

  const value = [
    '【為什麼有效】',
    '1) 先降溫：讓理性空間跑出來',
    '2) 再翻譯：把衝突變成可理解的需求',
    '3) 再練功：把小步驟變成神經回路',
    '（方向對了，當下即幸福）'
  ].join('\n');

  return [
    `Angel｜${typeName}提案（${dateStr}）`,
    '',
    `【提案主題】${topic || '（請填寫：主題一句話）'}`,
    `【對象】${audience || '（請填）'}`,
    `【目標】${goal || '（請填）'}`,
    `【時長】${duration || '（請填）'}`,
    `【主辦/場域】${host || '（請填）'}`,
    `【痛點關鍵字】${pain || '（可留空）'}`,
    notes ? `【補充】${notes}` : '',
    '',
    main.trim(),
    sub.trim(),
    '',
    outline,
    '',
    deliverables,
    '',
    value,
    '',
    '【一句話結尾】',
    '把心站穩，愛就有力量；方向對了，當下即幸福。',
  ].filter(Boolean).join('\n');
}

function generate() {
  const mainTool = findTool(els.toolMain.value);
  const subTool = findTool(els.toolSub.value);
  const text = proposalTemplate({
    type: proposalType,
    topic: els.topic.value.trim(),
    audience: els.audience.value.trim(),
    goal: els.goal.value.trim(),
    duration: els.duration.value.trim(),
    host: els.host.value.trim(),
    pain: els.pain.value.trim(),
    notes: els.notes.value.trim(),
    mainTool,
    subTool,
  });
  els.output.textContent = text;
  localStorage.setItem('angel_proposal_draft', JSON.stringify({
    proposalType,
    toolMain: els.toolMain.value,
    toolSub: els.toolSub.value,
    audience: els.audience.value,
    goal: els.goal.value,
    duration: els.duration.value,
    host: els.host.value,
    topic: els.topic.value,
    pain: els.pain.value,
    notes: els.notes.value,
    output: text,
  }));
}

function loadDraft() {
  const raw = localStorage.getItem('angel_proposal_draft');
  if (!raw) return;
  try {
    const d = JSON.parse(raw);
    setSegActive(d.proposalType || 'talk');
    els.toolMain.value = d.toolMain || '';
    els.toolSub.value = d.toolSub || '';
    els.audience.value = d.audience || '';
    els.goal.value = d.goal || '';
    els.duration.value = d.duration || '';
    els.host.value = d.host || '';
    els.topic.value = d.topic || '';
    els.pain.value = d.pain || '';
    els.notes.value = d.notes || '';
    els.output.textContent = d.output || '（尚未生成）';
  } catch {}
}

function getSaved() {
  try {
    return JSON.parse(localStorage.getItem('angel_saved_proposals') || '[]');
  } catch {
    return [];
  }
}

function setSaved(list) {
  localStorage.setItem('angel_saved_proposals', JSON.stringify(list));
  renderSaved();
}

function renderSaved() {
  const list = getSaved();
  if (list.length === 0) {
    els.savedList.innerHTML = `<div class="badge">尚無收藏。生成一份提案後，按「收藏此提案」。</div>`;
    return;
  }
  els.savedList.innerHTML = list.map(item => `
    <div class="item">
      <div class="meta">
        <div>
          <div style="font-weight:900">${item.topic || '（未命名）'}</div>
          <div style="font-size:12px;color:var(--muted);margin-top:3px">${item.typeLabel}｜${item.date}</div>
        </div>
        <div class="row">
          <button class="btn" data-action="open" data-id="${item.id}">打開</button>
          <button class="btn" data-action="del" data-id="${item.id}">刪除</button>
        </div>
      </div>
    </div>
  `).join('');

  els.savedList.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      const action = btn.dataset.action;
      const list2 = getSaved();
      const found = list2.find(x => x.id === id);
      if (!found) return;
      if (action === 'open') {
        els.output.textContent = found.output;
        // put back into draft
        localStorage.setItem('angel_proposal_draft', JSON.stringify({
          proposalType: found.type,
          toolMain: found.toolMain,
          toolSub: found.toolSub,
          audience: found.audience,
          goal: found.goal,
          duration: found.duration,
          host: found.host,
          topic: found.topic,
          pain: found.pain,
          notes: found.notes,
          output: found.output,
        }));
        loadDraft();
        window.scrollTo({top:0, behavior:'smooth'});
      } else if (action === 'del') {
        setSaved(list2.filter(x => x.id !== id));
      }
    });
  });
}

function saveCurrent() {
  const output = els.output.textContent;
  if (!output || output === '（尚未生成）') {
    alert('請先生成提案。');
    return;
  }
  const list = getSaved();
  const now = new Date();
  const id = `p_${now.getTime()}`;
  const typeLabel = proposalType === 'talk' ? '演講' : (proposalType === 'course' ? '課程' : '活動');
  list.unshift({
    id,
    date: `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`,
    type: proposalType,
    typeLabel,
    toolMain: els.toolMain.value,
    toolSub: els.toolSub.value,
    audience: els.audience.value,
    goal: els.goal.value,
    duration: els.duration.value,
    host: els.host.value,
    topic: els.topic.value,
    pain: els.pain.value,
    notes: els.notes.value,
    output,
  });
  setSaved(list.slice(0, 50));
  alert('已收藏！');
}

function resetAll() {
  els.toolMain.value = '';
  els.toolSub.value = '';
  els.audience.value = '';
  els.goal.value = '';
  els.duration.value = '';
  els.host.value = '';
  els.topic.value = '';
  els.pain.value = '';
  els.notes.value = '';
  els.output.textContent = '（尚未生成）';
  localStorage.removeItem('angel_proposal_draft');
}

async function copyOutput() {
  const text = els.output.textContent || '';
  if (!text || text === '（尚未生成）') return alert('請先生成提案。');
  try {
    await navigator.clipboard.writeText(text);
    alert('已複製！');
  } catch {
    // fallback
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
    alert('已複製！');
  }
}

function setupInstallPrompt() {
  let deferredPrompt = null;
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    els.btnInstall.hidden = false;
    els.btnInstall.addEventListener('click', async () => {
      if (!deferredPrompt) return;
      deferredPrompt.prompt();
      await deferredPrompt.userChoice;
      deferredPrompt = null;
      els.btnInstall.hidden = true;
    }, { once:true });
  });
}

function registerSW() {
  if (!('serviceWorker' in navigator)) return;
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(()=>{});
  });
}

function wireEvents() {
  $$('.seg-btn').forEach(btn => {
    btn.addEventListener('click', () => setSegActive(btn.dataset.type));
  });
  els.btnGenerate.addEventListener('click', generate);
  els.btnCopy.addEventListener('click', copyOutput);
  els.btnDownload.addEventListener('click', () => downloadText('angel-proposal.txt', els.output.textContent || ''));
  els.btnSave.addEventListener('click', saveCurrent);
  els.btnReset.addEventListener('click', resetAll);
  els.btnExportCsv.addEventListener('click', () => {
    downloadText('angel-tools-database.csv', toolsToCsv());
  });
}

function init() {
  fillToolSelects();
  wireEvents();
  setupInstallPrompt();
  registerSW();
  renderSaved();
  loadDraft();
}

init();
